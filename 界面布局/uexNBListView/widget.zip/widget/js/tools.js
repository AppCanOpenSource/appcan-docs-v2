function getIndexFromId(id){
    return id.substring(id.length-1, id.length);
}