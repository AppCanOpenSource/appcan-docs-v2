appcan.define("unlimitedtreeview", function($, exports, module) {

    var listTmp ='<li class="unlimitedtreeview">\
        <div class="unlimitedtreeview-header ubb bc-border bc-text ub uinn ub-ac">\
        <%if (option.hasIcon) {%>\
        <div class="lis-icon-s ub-img" style="background-image:url(<%=icon%>)"></div>\
        <%}%>\
        <div class="ub-f1 ut-s"><%=header%></div>\
        <%if(option.hasAngle){%>\
        <div class="fa fa-angle-down ulev2 utra sc-text"></div>\
        <%}%>\
        </div>\
        <div class="unlimitedtreeview-content umh6 bc-text uhide">\
        <%=content%>\
        </div>\
        </li>';
        
    var listRender = appcan.view.template(listTmp);

    var isEmulator = !('ontouchstart' in window);

    var touchEvent = {
        'start' : isEmulator ? 'mousedown' : 'touchstart',
        'move' : isEmulator ? 'mousemove' : 'touchmove',
        'end' : isEmulator ? 'mouseup' : 'touchend',
        'cancel' : 'touchcancel'
    };
    var onclickNum = 0;
    var trflage = 0;
    var treeClick = null; 
    var Unlimitedtreeview = function(option) {
        appcan.extend(this, appcan.eventEmitter);
        this.option = $.extend({
            selector : "body",
            type : '',
            hasIcon : false,
            hasAngle : true,
            hasTouchEffect : true,
            touchClass : 'sc-bg-active',
            isCloseOther : true,
            defaultOpen : -1,
            autoScrollTop : false,
            myMargin:'1.25'
        }, option, true);
        this.ele = $(this.option.selector);
        if (this.option.data) {
            this.set(this.option.data);
        }
        this.open(this.option.defaultOpen);
    };

    Unlimitedtreeview.prototype = {
        constructor : Unlimitedtreeview,
        createPlugin : function(selector) {
            if (!this.plugin) {
                return;
            }
            var option = $.extend({
                selector : selector
            }, this.pluginOption, true);
            return this.plugin(option);
        },
        getChildContent: function(data){
            var self = this;
            var contentData = data.content;
            var lastContentData = data.lastContent;
            if (!contentData && !lastContentData) {
                return;
            }
            contentData = contentData || lastContentData;
            if ((appcan.isArray(contentData) || appcan.isPlainObject(contentData)) && !$.zepto.isZ(contentData)) {
               var container = $(' <ul style="margin-left: '+self.option.myMargin+'em;"></ul>');
                for (var i in contentData) {
                    var html = listRender;
                    var ele = $(html({
                        header : contentData[i].header,
                        icon:contentData[i].icon,
                        content : '',
                        option : self.option
                    }));
                    var tvHeader = ele.find('.unlimitedtreeview-header');
                    tvHeader[0]["tv_data"] = contentData[i];
                    tvHeader.on('tap', function(evt) {

                        self.treeItemClick(evt);
                    });

                    tvHeader.on('longTap', function(evt) {
                        self.longTapItem(evt,self);
                    });
                    tvHeader.on('swipe', function(evt) {
                        self.longTapItem(evt,self);
                    });
                    ele.on('tap', function(evt) {   
                        evt.cancelBubble = true;
                        if(!($(evt.currentTarget)[0].children[1])){
                          if(!treeClick){ 
                           treeClick = setTimeout(function(){
                              self.itemClick(evt,self);
                              treeClick = null;
                          },300);
                          }
                        }                  
                    });
                    
                    ele.on('doubleTap', function(evt) {
                        evt.cancelBubble = true;
                        clearTimeout(treeClick);
                        treeClick = null;
                        if(!($(evt.currentTarget)[0].children[1])){
                             if($(evt.currentTarget).attr('trflage') != '1'){
                            var len = $(evt.currentTarget).parents('.unlimitedtreeview').length;
                            $(evt.currentTarget).css({'margin-left':-parseInt(self.option.myMargin)*len+'em'});
                              $(evt.currentTarget).attr('trflage','1');
                            }else{
                               $(evt.currentTarget).css({'margin-left':0+'em'}); 
                                $(evt.currentTarget).attr('trflage','0');
                            }
                         }
                    });
                    var content = self.getChildContent(contentData[i]);
                    if (content) {
                        ele.find('.unlimitedtreeview-content').html(content);
                    } else {
                        ele.find('.unlimitedtreeview-header .fa-angle-down').removeClass('fa-angle-down');
                        ele.find('.unlimitedtreeview-content').remove();
                    }
                    
                    container.append(ele);
                }
            }
            
            return container;
        },
        buildUnlimitedtreeview : function(data, settings) {
            
            var container = $("<ul></ul>");
            var self = this;
            
            for (var i in data) {
                var html = listRender;
                var option = {};
                option = $.extend({}, settings && settings.option, true);
                option = $.extend(option, data[i].option, true);
                var processType = data[i].type || (settings && settings.type);
                settings = {
                    option : option,
                    type : processType
                };
                var content = self.getChildContent(data[i]);
                var ele = $(html({
                    header : data[i].header,
                    icon:data[i].icon,
                    content : '',
                    option : self.option
                }));
                
                var tvHeader = ele.find('.unlimitedtreeview-header');
                tvHeader[0]["tv_data"] = data[i];
                if (!settings.type) {
                    if (content) {
                        ele.find('.unlimitedtreeview-content').html(content);
                    } else {
                        ele.find('.unlimitedtreeview-header .fa-angle-down').removeClass('fa-angle-down');
                        ele.find('.unlimitedtreeview-content').remove();
                    }
                } else {
                    ele[0]['plugin'] = content;
                }
                tvHeader.on('tap', function(evt) {
                    self.treeItemClick(evt);
                });
                tvHeader.on('longTap', function(evt) {
                    self.longTapItem(evt);
                });
                tvHeader.on('swipe', function(evt) {
                    self.longTapItem(evt);
                });
                ele.on('tap', function(evt) {   
                    evt.cancelBubble = true;
                    if(!($(evt.currentTarget)[0].children[1])){
                      if(!treeClick){ 
                       treeClick = setTimeout(function(){
                          self.itemClick(evt,self);
                          treeClick = null;
                      },300);
                      }
                    }                  
                });
                
                ele.on('doubleTap', function(evt) {
                    evt.cancelBubble = true;
                    clearTimeout(treeClick);
                    treeClick = null;
                    if(!($(evt.currentTarget)[0].children[1])){
                        if($(evt.currentTarget).attr('trflage') != '1'){
                        var len = $(evt.currentTarget).parents('.unlimitedtreeview').length;
                        $(evt.currentTarget).css({'margin-left':-parseInt(self.option.myMargin)*len+'em'});
                        $(evt.currentTarget).attr('trflage','1');
                        }else{
                            $(evt.currentTarget).css({'margin-left':0+'em'}); 
                            $(evt.currentTarget).attr('trflage','0');
                        }
                     }
                });
                
                container.append(ele);
            }
            return container;
        },
        
        set : function(data, settings) {
            var self = this;
            var container = self.buildUnlimitedtreeview(data, settings);
            
            self.ele.html(container);
            return self;
        },
        
        add : function(data,dir,settings) {
            var self = this;
            var container = self.buildUnlimitedtreeview(data,settings);
            if (dir != "0") {
                var last = self.ele.children().first();
                last.append(container.children());
            } else {
                var first = self.ele.children().first();
                first.prepend(container.children());
            };
            return self;
        }, 
        
        itemClick : function(evt) {
            var self = this;
            var obj = $(evt.srcElement || evt.target).closest('.unlimitedtreeview-header').parent();
            var tvHeader = obj.find('.unlimitedtreeview-header');
            this.emit("click", self, obj, $(evt.target), tvHeader[0]["tv_data"]);
           return false;
        },
        
        treeItemClick : function(evt) {
            var unlimitedtreeviewHeader = $(evt.currentTarget);
            var data = unlimitedtreeviewHeader[0]["tv_data"];
            if(data.content){
                this.showItem(unlimitedtreeviewHeader);
            }
        },
        
        showItem : function(header) {
            var unlimitedtreeviewHeader = header;
            var obj = unlimitedtreeviewHeader.parent();

            var contentEle = $(obj.find('.unlimitedtreeview-content')[0]);
            if(unlimitedtreeviewHeader.length){
                var data = unlimitedtreeviewHeader[0]["tv_data"];
                if(data.content){
                    obj.siblings().find('.unlimitedtreeview-header').removeClass(this.option.touchClass);
                 } 
            }
            if (this.option.isCloseOther) {
                obj.siblings().find('.unlimitedtreeview-content').addClass('uhide');
                obj.find('.fa-angle-down').removeClass('fa-rotate-180');
                $(obj.siblings().find('.fa-angle-down')).removeClass('fa-rotate-180');
                obj.find('li').css({'margin-left':0+'em'});
            }
            if (contentEle.hasClass('uhide')) {
                contentEle.removeClass('uhide'); 
                unlimitedtreeviewHeader.addClass(this.option.touchClass);
                $(obj.find('.fa-angle-down')[0]).addClass('fa-rotate-180');
            } else { 
                obj.find('.unlimitedtreeview-header').removeClass(this.option.touchClass);
                $(obj.find('.unlimitedtreeview-content')).addClass('uhide');
                unlimitedtreeviewHeader.removeClass(this.option.touchClass);
                obj.find('.fa-angle-down').removeClass('fa-rotate-180');
                obj.find('li').css({'margin-left':0+'em'});
                trflage = 0;
                
            }
            if (this.option.autoScrollTop) {
                var offset = unlimitedtreeviewHeader.offset();
                var top = offset && offset.top || 0;
                $(window).scrollTop(top);
            }
        },
        
        touchItem : function(evt) {
            var self = this;
            var obj = $(evt.currentTarget);
            if (this.option.hasTouchEffect ) {
                var data = obj[0]["tv_data"];
                obj.addClass(self.option.touchClass);
                if(!data.content)
                {
                    setTimeout(function(){
                        obj.removeClass(self.option.touchClass);
                    },60);
                }
            }
        },
        
        longTapItem : function(evt) {
            if(this.option.hasTouchEffect){
                var header = $(evt.currentTarget);;
                var obj = header.parent();
                var contentEle = obj.find('.unlimitedtreeview-content');
                if(contentEle.hasClass("uhide")){
                    header.removeClass(this.option.touchClass);
                }
            }
           
        },
        
        //打开索引位置的选项
        open : function(index) {
            index = parseInt(index, 10);
            if (isNaN(index) || index < 0) {
                return;
            }
            this.showItem(this.ele.find('.unlimitedtreeview').eq(index).find('.unlimitedtreeview-header'));
        },
        hideItem:function(header){
            var unlimitedtreeviewHeader = header;
            var obj = unlimitedtreeviewHeader.parent();
            
            var contentEle = obj.find('.unlimitedtreeview-content');
            if(unlimitedtreeviewHeader.length){
                var data = unlimitedtreeviewHeader[0]["tv_data"];
                if(data.content){
                    obj.siblings().find('.unlimitedtreeview-header').removeClass(this.option.touchClass);
                }
            }
            if (contentEle.hasClass('uhide')) {
                //contentEle.removeClass('uhide');
                //unlimitedtreeviewHeader.addClass(this.option.touchClass);
                //obj.find('.fa-angle-down').addClass('fa-rotate-180');
            } 
            else {
                contentEle.addClass('uhide');
                unlimitedtreeviewHeader.removeClass(this.option.touchClass);
                obj.find('.fa-angle-down').removeClass('fa-rotate-180');
            }
            if (this.option.autoScrollTop) {
                var offset = unlimitedtreeviewHeader.offset();
                var top = offset && offset.top || 0;
                $(window).scrollTop(top);
            }
            
        },
        
        //收起指定所以位置的选项
        hide:function(index){
            index = parseInt(index, 10);
            if (isNaN(index) || index < 0) {
                return;
            }
            this.hideItem(this.ele.find('.unlimitedtreeview').eq(index).find('.unlimitedtreeview-header'));
        },
        
        //收起所有的选项
        hideAll:function(){
            for(var i=0,len=this.ele.find('.unlimitedtreeview').length;i<len;i++){
                this.hide(i);
            }
        }
    };

    module.exports = function(option) {
        return new Unlimitedtreeview(option);
    };
});
